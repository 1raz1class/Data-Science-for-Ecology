THEANO_FLAGS=mode=FAST_RUN,device=gpu,floatX=float32 python2 cnn_predict_stack.py DukeTurtle_test.mat
